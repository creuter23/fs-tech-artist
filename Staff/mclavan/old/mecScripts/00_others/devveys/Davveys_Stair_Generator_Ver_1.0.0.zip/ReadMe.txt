/////////////////////////////////////////////////////////////////////////////			
/*				
	Copyright � 2006 DVY_Stairs. All rights reserved davvey@ntlworld.com

						- DVY_Stairs -
						
/////////////////////////////////////////////////////////////////////////////

Note:- Any Duplicate files contained in any of my script packs can be used.
Just ensure you copy the latest version of any file.
These script packs are being built up using some common utility type scripts
which are shared across more than one pack.						
						
	DVY_Stairs;
	Description and Usage Section
	
	Installation	

	Just install scripts in any Maya script path and install
	Icon and Image files in May\\Prefs\Icons directory
						
	Description	
	
	Usage

	Type DVY_Stairs in command line or middle mouse drag it to a shelf.
	There is an Icon file supplied to use with the Shelf Button.
	
	Description	

	This script calls a GUI where relevant Info can be entered to generate 
	a dimensionally accurate Stairs of various designs.

	The Scripts will currently build both Straight and Spiral sets of Stairs.
	There are various options that can be selected and Data fields to enter
	various sizes. For Straight Stairs these are Tread Width, Tread Depth,
	Step Height and Step Thickness. If Step Height and Thickness are set the
	same script will effectively build a set of steps not stairs.
	
	The straight Step options are to include Stair Risers (i.e. the vertical
	section of each step) but not needed for the solid step settings example
	above. Stairs are built with a 20mm overhang and there are options for edge
	of step styles. There is an option to include Stair Rails each side. These
	can either be on outside edge (will add approx. 35mm to overall width) or
	they can be set inboard of the steps in which case the rails will be notched 
	to suit the Step thickness. \nThere are options for Left and Right Hand and
	Mid Rails, with post and wall mounting options. Also if posts are selected
	Panels can be built for left, right or both sides. 

	For Spiral Stairs the options are Stair Outside Diameter, Tread Width,
	Step Height and Step Thickness. Also Outside and Inside HandRails with Posts
	or Wall Mountings. Also Panels are available for the Outside Diameter.
	There is and Option to include a central column if required. 

	After building the Stairs the script will lock off unused attributes and
	leave the Main group Translate and Rotate Nodes unlocked and keyable.

	Note:- The Scale of the Stairs will be adjusted to set correct size
	relevant to the correct size for the Users Maya Unit settings 
	i.e mm, cm, m, in, ft, yd.
	
	Also included with the script download pack are some guidance notes on
	building stairs this is in the form of a Help Txt File.

Installation example (for Maya 8.0):

1. Install scripts in the Maya Script directory
	E:\Documents and Settings\Davvey\My Documents\Maya\8.0\scripts

2. Install all icons (xpm files) in
	E:\Documents and Settings\Davvey\My Documents\Maya\8.0\prefs\icons
	
	Davvey
If you like the scripts please rate them.

I Thought I saw Light at the end of the Tunnel
but it was just some Bxxxxxx with more troubles.

davvey@ntlworld.com