
///////////////////////////////////////////////////////////////////////////////
/*			
				
	Copyright � 2006 DVY_Bearings. All rights reserved davvey@ntlworld.com

						- DVY_Bearings -
///////////////////////////////////////////////////////////////////////////////
						
//	DVY_Bearings;
//	Description and Usage Section

//	Installation	

	Just install scripts in any Maya script path and install
	Icon in May\\Prefs\Icons directory (to use with any Shelf button)


//	Description Section

	These Scripts will build Dimensional accurate Metric Bearings using the
	relevant ISO Standards and the GUI will show the English Equivalent
	during the setting up of the vrious options. The Metric Bearings
	manufactured to the following standards are covered by

	�  	metric radial rolling bearings in standard ISO 15:1998,
		except taper roller bearings

	� 	metric radial taper roller bearings in standard ISO 355:1977

	� 	metric thrust rolling bearings in standard ISO 104:2002.
	
	Ball bearings are made in a wide variety of types and sizes. Single-row 
	radial bearings are made in four series, extra light (100), light (200),
	medium (300), and heavy (400), for each bore. 

	Most, but not all, manufacturers use a numbering system so devised that
	if the last two digits are multiplied by 5, the result will be the bore
	in millimeters. The digit in the third place from the right indicates
	the series number. Thus, bearing 307 signifies a medium-series bearing
	of 35-mm bore.
	

	The GUI will call the relevant script to build the required Bearings.
	The Bushes can be produced in default Lambert or a choice of various 
	basic materials. The Ball and Roller Bearing will be shader in simple
	steel and Brass Shaders as required.
		
	After construction of the various parts the Inner and Outer rotations
	are connected to the Roller and Cage rotations. Inside and Outside can
	be rotated in Y Axis independantly.
	
	Self aligning Bearings can also be rotated in X and Y and Roller and
	Cages will also rotate  as required.
	
	All Bearings are produced to Metric Bearing Standards and the Size/Scale is
	correctly set to suit Maya's user preferences settings.

	The Bush Bearings can be Full, Half or Split and Plain, Single or Double ended 
	Flanged in style. 	


// Usage Section

	These scripts build Metric Bearings but the UI will show the english 
	equivalent sizes during setup.
		
	Many catalogues display a more comprehensive range than this but many
	sizes will not be readily available 'off-the-shelf'. 
	

	Davvey

	If you like the scripts please rate them.

	I Thought I saw Light at the end of the Tunnel
	but it was just some Bxxxxxx with more troubles.

	davvey@ntlworld.com
