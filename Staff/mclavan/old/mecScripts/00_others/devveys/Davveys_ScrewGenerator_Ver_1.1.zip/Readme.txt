DVY_Screws

/////////////////////////////////////////////////////////////////////////////		
				
	Copyright � 2006 DVY_Screws. All rights reserved 

/////////////////////////////////////////////////////////////////////////////

Note:- Any Duplicate files contained in any of my script packs can be used.
Just ensure you copy the latest version of any file.
These script packs are being built up using some common utility type scripts
which are shared across more than one pack.						

Just install scripts in any Maya script path and install Icon filesin Maya\Prefs\Icons directory (to use with a Shelf button).

Also install all Button Images to any Maya icon path (see examples below for Maya 8.0)

To use this these scripts Select Diameter required. Then Select Length required.
GUI will calculate and display nearest English equivalents for Diameter, Gauge and Length

The Standard Pitches used are for Metric sizes and equivalents are displayed. Self Tappers use different pitches for certain Diameters / Gauges.

Then select Screw Type (WoodScrew, Decking Screw, Twin Threaded, ChipBoard, DryWall or Self Tapper).

Then select quantity to  be produced.
Each `Group` Node produced will contain one screw only.
If More than one required the Group Node will be parented under a `MainScrew` Group node.
If other Sizes of items required re-run to suit needs.

Each Thread is a Nurbs Surface parented under the Polygon Shape Tranform Node.
Each Threaded item has been setup that when moved in the `Y` axis the item will Rotate in `Y` axis at  a rate to match the pitch of the thread

Option now includes adding a simple shader for Steel, Stainless,  Black, Aluminium, Brass and Copper shaders.
 
Installation example (for Maya 8.0):

1. Install scripts in the Maya Script directory
	E:\Documents and Settings\Davvey\My Documents\Maya\8.0\scripts

2. Install all icons (xpm files) in
	E:\Documents and Settings\Davvey\My Documents\Maya\8.0\prefs\icons
	
Davvey

If you like the scripts please rate them.

I Thought I saw Light at the end of the Tunnel
but it was just some Bxxxxxx with more troubles.

davvey@ntlworld.com

