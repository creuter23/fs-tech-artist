
/////////////////////////////////////////////////////////////////////////////			
/*				
	Copyright � 2007 DVY_Lego. All rights reserved davvey@ntlworld.com

						- DVY_Lego -
						
/////////////////////////////////////////////////////////////////////////////

Note:- Any Duplicate files contained in any of my script packs can be used.
	  Just ensure you copy the latest version of any file.
	  These script packs are being built up using some common utility 
	  type scripts which are shared across more than one pack.	
						
	Usage

	Type DVY_Lego in command line or middle mouse drag it to a shelf.
	There is an Icon file supplied to use with the Shelf Button.
	
	Description	

	This script calls a GUI where relevant Info can be entered to generate
	dimensionally accurate Lego Parts. 
	
	After construction the Parts are named according to Colour (if selected) 
	Part type, 	and Number of Pitches of Lego and a sequential number.
	If there is a Part of exactly the same size and type the script will
	automatically number the Part with next available number.
	The Names used in the naming are based on the naming convention used
	in the Option Menu list which are based on the standard Parts from
	the Lego Parts List.
	
	The pitch of Lego parts are 8 mm in X and Z Axis and either
	 3.2 or 9.6 mm in Y Axis  (Plate and Brick height)
	
	Note:- The Scale of the Parts will be adjusted to set correct size 
	relevant to the correct size for the Users Maya Unit settings
	i.e mm, cm, m, in, ft, yd.
	
	If there are any additional Lego Parts you would like added to
	the list please let me know at Davvey@ntlworld.com and I will try
	and add them to the scripts.	
	
	See http://factory.lego.com/ and check out "Get a Brick" link to
	locate required parts. Drop me an e-mail with part no. required.
					
 	Installation
	
	Install all scripts in any Maya Script folder and install all image files
	in Maya's Icon folder. 

	Installation example (for Maya 8.0):
	
	1. Install scripts in the Maya Script directory
		E:\Documents and Settings\Davvey\My Documents\Maya\8.0\scripts
		
	2. Install all icons (xpm files) in
		E:\Documents and Settings\Davvey\My Documents\Maya\8.0\prefs\icons
		
**********************************************************************

	 "Lego" is a trademark of The Lego Group.  These scripts etc are not endorsed
	 by The Lego Group nor does it receive endorsement from it.  It is just for fun.
	 All trademarks and copyrights are respected.
	 
**********************************************************************	
Davvey

If you like the scripts please rate them.

I Thought I saw Light at the end of the Tunnel
but it was just some Bxxxxxx with more troubles.

davvey@ntlworld.com
