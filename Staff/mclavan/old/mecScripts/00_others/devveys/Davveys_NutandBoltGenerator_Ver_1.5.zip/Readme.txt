DVY_BoltandNut

/////////////////////////////////////////////////////////////////////////////		
				
	Copyright � 2006 DVY_BoltandNut. All rights reserved 

/////////////////////////////////////////////////////////////////////////////

Note:- Any Duplicate files contained in any of my script packs can be used.
Just ensure you copy the latest version of any file.
These script packs are being built up using some common utility type scripts
which are shared across more than one pack.						


Increased options for Bolt Heads to include "Coach" Bolt, Panhead and Cheesehead 
style Bolts. Also added Flanged, Domed and Castellated (use with split pins) and Wing Nuts.

These Scripts will build Metric Nuts, Bolts and Washers to exact scale and specification as per DIN Standards

To use this these scripts Select Diameter required. Standard Pitch is the only one currently available. Then select quantiy to be produced. Each `Set` produced will contain the same group of items.

If other `Groups` of items required re-run to suit needs. If you require a `Threaded Hole` to fit in a surface then run script as required and create a plain hole of the correct thread diameter and place the `Dummy Hole` inside it.

Each Thread has had a smoothing action applied to the Polygon section but it is set at `Zero` subdivision Levels until smoothing is required. Each Threaded item has been setup that when moved in the `Y` axis the item will Rotate in `Y` axis at a rate to match the pitch of the thread" .

 Option now included adding a simple shader for Steel, Stainless,  Blacke, Aluminium, Barss and Copper shaders.
To use install all scripts in any Maya Script Path and type DVY_BoltandNut in command line to start GUI.


Installation example (for Maya 8.0):

1. Install scripts in the Maya Script directory
	E:\Documents and Settings\Davvey\My Documents\Maya\8.0\scripts

2. Install all icons (xpm files) in
	E:\Documents and Settings\Davvey\My Documents\Maya\8.0\prefs\icons
	
Davvey

If you like the scripts please rate them.

I Thought I saw Light at the end of the Tunnel
but it was just some Bxxxxxx with more troubles.

davvey@ntlworld.com

Thanls to Jeff Lovering for the Icon Image