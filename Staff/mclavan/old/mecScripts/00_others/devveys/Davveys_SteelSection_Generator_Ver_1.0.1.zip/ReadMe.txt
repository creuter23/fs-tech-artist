/////////////////////////////////////////////////////////////////////////////			
/*				
	Copyright � 2006 DVY_Steel. All rights reserved davvey@ntlworld.com

						- DVY_Steel -
						
/////////////////////////////////////////////////////////////////////////////

Note:- Any Duplicate files contained in any of my script packs can be used.
Just ensure you copy the latest version of any file.
These script packs are being built up using some common utility type scripts
which are shared across more than one pack.						

	DVY_Steel;
	Description and Usage Section
	
	Installation	

	Just install scripts in any Maya script path and install
	Icon and Image files in May\\Prefs\Icons directory
						
	Usage

	Type DVY_Steel in command line or middle mouse drag it to a shelf.
	There is an Icon file supplied to use with the Shelf Button.
	
	Installation
	
	Install all scripts in any Maya Script folder and install all image files
	in Maya's Icon folder.
	
	Description	
	
	This script calls a GUI where relevant Info can be entered to generate
	dimensionally accurate Steel Sections. The script will build Joist,
	Tapered Flange Channels. Tapered Flange Tee-Bars, Tee-Bar from Universal
	Beams, Equal Angle and Un-Equal Angles (with parallel flanges),
	Universal Beams, Universal Columns, Hollow Square and Rectangle Sections.
	The sizes range from 20 mm up to 500 mm depending on Section chosen.
	The scripts will build over 500 different sizes sections in total.
	
	The Steel Sections are built with nominal sizes as per each OptionMenu list.
	The default length for each Section is 1000 mm (39.4 inches).
	
	This can be adjusted by entering required length in the data field.
	After setting required length select type and size of section required.
	The script will build a Polygon Section of the required type. The sizes
	used are from the relevant Standards for Steel Sections which are:-
	
	Structural Sections to BS4: Part 1: 1993 and BS EN10056: 1999
	Also they are Dimensionally similar to BS EN10034: 1993	and
	BS EN10056-2: 1993 (European Standards).
	
	Most of the sections also have a comparable or equivalance in Structural
	sections to ASTM specifications ASTM A6/A6M.
	
	After construction the sections are named according to section type,
	dimensions (Height x Width x Length) and a sequential number.
	If there is a section of exactly the same size and type the script will
	automatically number the section with next available number. The Dimensions
	used in the naming are not the sections exact sizes but are based on the 
	naming convention used in the Option Menu list which are based on the
	designations from the above Standards Tables of sizes and Specifications
	
	Note:- The Scale of the Section will be adjusted to set correct size 
	relevant to the correct size for the Users Maya Unit settings
	i.e mm, cm, m, in, ft, yd.
	
	If there are any additional steel sections you would like added to
	the list please let me know at Davvey@ntlworld.com and I will try
	and add them to the scripts.				
	

Installation example (for Maya 8.0):

1. Install scripts in the Maya Script directory
	E:\Documents and Settings\Davvey\My Documents\Maya\8.0\scripts

2. Install all icons (xpm files) in
	E:\Documents and Settings\Davvey\My Documents\Maya\8.0\prefs\icons
	
	Davvey
If you like the scripts please rate them.

I Thought I saw Light at the end of the Tunnel
but it was just some Bxxxxxx with more troubles.

davvey@ntlworld.com